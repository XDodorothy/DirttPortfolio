//SECTION JEU DE ROULETTE//

let solde = 0;
let montant = 0;
let mise = 0;
let noirClicked = false;
let rougeClicked = false;
let color;
// PROGRAMMATION AJOUTER SOLDE
document.getElementById('ajout').addEventListener("click", ajoutSolde);
function ajoutSolde (){
    montant = parseFloat(prompt("Quel montant souhaitez-vous ajouter ?"));
    solde = solde + montant;
    document.getElementById("solde").innerHTML = 'Votre solde est : '  + solde + '$';
}
//PROGRAMMATION RETIRER SOLDE
document.getElementById('retire').addEventListener("click", retireSolde);
function retireSolde (){
    montant = parseFloat(prompt("Quel montant souhaitez-vous retirer ?"));
    solde = solde - montant;
    document.getElementById("solde").innerHTML = 'Votre solde est : '  + solde + '$';
}
//PROGRAMMATION AJOUTER MISE
//Rouge
document.getElementById("rouge").addEventListener("click", miserRouge);
function miserRouge(){
    if (solde == 0) {
        alert("Mise impossible, solde insuffisant");
    }
    else {
        rougeClicked = true; // Prévenir que le Noir soit cliqué
        if (noirClicked == true) {
            alert("Mise impossible, veuillez annuler la mise sur le noir");
        }
        else {
            montant = parseFloat(prompt("Quel montant désirez-vous miser sur le rouge ?"));
            if (montant > solde){
                alert("Retrait impossible, solde insuffisant");
                if (mise == 0) {
                    rougeClicked = false; // si il n'y avait pas déjà de mise, il a le droit de miser sur le noir finalement aussi
                }
            }
            else {
                mise = mise + montant;
                document.getElementById("mise").innerHTML = 'Votre mise totale est : '  + mise + '$';
                solde = solde - montant;
                document.getElementById("solde").innerHTML = 'Votre solde est : '  + solde + '$';
            }
        }
    }
}
//Noir
document.getElementById("noir").addEventListener("click", miserNoir);
function miserNoir(){
    if (solde == 0) {
        alert("Mise impossible, solde insuffisant");
    }
    else{
        noirClicked = true; // Prévenir que le Rouge soit cliqué
        if (rougeClicked == true) {
            alert("Mise impossible, veuillez annuler la mise sur le rouge");
        }
        else{
            montant = parseFloat(prompt("Quel montant désirez-vous miser sur le noir ?"));
            if (montant > solde){
                alert("Retrait impossible, solde insuffisant");
                if (mise == 0) {
                    noirClicked = false; // si il n'y avait pas déjà de mise, il a le droit de miser sur le rouge finalement aussi
                }
            }
            else {
                mise = mise + montant;
                document.getElementById("mise").innerHTML = 'Votre mise totale est : '  + mise + '$';
                solde = solde - montant;
                document.getElementById("solde").innerHTML = 'Votre solde est : '  + solde + '$';
            }
        }
    }
}
// PROGRAMMATION ANNULER LA MISE
document.getElementById('annuler').addEventListener("click", annulerMise);
function annulerMise (){
    solde = solde + mise;
    mise = 0;
    document.getElementById("mise").innerHTML = 'Votre mise totale est : '  + mise + '$';
    document.getElementById("solde").innerHTML = 'Votre solde est : '  + solde + '$';
    rougeClicked = false; // réinitialiser la joute
    noirClicked = false; // réinitialiser la joute
}


//PROGRAMMATION JOUER

let roue = document.getElementById("roue"); //Récupération de l'image
let JRouge = document.getElementById("rouge");
let JNoir = document.getElementById("noir");
document.getElementById('jouer').addEventListener("click", jeu);

function jeu (){
    if (mise == 0){
        alert("Vous devez effectuer une mise pour pouvoir jouer");
    }
    else{
        roue.style.cssText = 'animation: rotation 5s linear;';
        if (noirClicked == true){
            JNoir.style.backgroundImage = 'radial-gradient(black, green)';
        }
        else{JRouge.style.backgroundImage = 'radial-gradient(red, green)';}
        //Remettre le style de la roue a zéro après 5 sec avec Timeout - Fonction Fléchée  
        setTimeout(() => {
            roue.style.cssText = '';
            let nombre = getRndInteger(1, 37);
            color = modulo(nombre);
            if (rougeClicked == true && color == "rouge") {
                alert ("Le nombre sorti est " + nombre + " " + color + ", vous avez gagné");
                solde = solde + 2 * mise;
                mise = 0;
                document.getElementById("mise").innerHTML = 'Votre mise totale est : '  + mise + '$';
                document.getElementById("solde").innerHTML = 'Votre solde est : '  + solde + '$';
            }
            else if (noirClicked == true && color == "noir"){
                alert ("Le nombre sorti est " + nombre + " " + color + ", vous avez gagné");
                solde = solde + 2 * mise;
                mise = 0;
                document.getElementById("mise").innerHTML = 'Votre mise totale est : '  + mise + '$';
                document.getElementById("solde").innerHTML = 'Votre solde est : '  + solde + '$';
            }
            else {
                alert ("Le nombre sorti est " + nombre + " " + color + ", vous avez perdu");
                mise = 0;
                document.getElementById("mise").innerHTML = 'Votre mise totale est : '  + mise + '$';
            }
            rougeClicked = false; // réinitialiser la joute
            noirClicked = false; // réinitialiser la joute  
            JRouge.style.backgroundImage = ''; // réinitialiser la joute 
            JNoir.style.backgroundImage = ''; // réinitialiser la joute 
            
            
        }, 5000)//(après 5000 milisecondes, reset)
        
    }
    
}
//Aléatoire
function getRndInteger(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}
//Pair ou Impair ?
function modulo(x){
    
    if (x % 2 == 0){
        return "rouge";
    }
    else { return "noir"}
}
