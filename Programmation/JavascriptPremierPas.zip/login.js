//SECTION CONNECTION//

let validation = document.getElementById('bouton_envoie'); // Cible le bouton d'envoie - TOUJOURS UTLISIER VIA LE BOUTON LORS DE VALIDATION DE FORMULAIRE (PLUTÔT QUE DE VISER LE FORMULAIRE)
validation.addEventListener('click', inscrit);
let invalide = document.getElementById('invalide');

function inscrit(e){
    e.preventDefault();
    let nu = document.getElementById('nu');
    let mdp = document.getElementById('mdp');
    
    if ((nu.value != "Osullivan") || (mdp.value != "Osullivan2023"))//mauvaises entrées
    {   
        invalide.textContent = 'Crédentiels invalides';
        document.getElementById('invalide').style.color = 'red';
        nu.value = '';
        mdp.value = '';
        
    } 
    else {
        window.location.href='roulette.html';
    }
}

