//Importations
import React from "react";
import Navigation from "../components/Navigation";
import Logo from "../components/Logo";
import MenuFiltre from "../components/MenuFiltre";

//Création du composant
const Categories = () => {
    //Backend
    //Frontend
    return(
        <div className="Categories">
            <Logo />
            <Navigation />
            <br></br>
            <MenuFiltre />
        </div>
    )
}

//Exportation du composant
export default Categories;