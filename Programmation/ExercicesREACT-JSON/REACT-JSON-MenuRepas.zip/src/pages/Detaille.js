//Imports
import React, {useState, useEffect} from "react";
import axios from "axios";

//Fonction normale --> MÊME CHOSE QUE FLECHÉES, mais nous allons toujours utilisée Fechées, car plus populaire/standard
/*function Home() {}*/
//Création composante (Créer une fonction fléchée)
const Detaille = (props) => { // toujours mettre PROPS dans les parenthèses quand on l'utilise
    //Backend

    const idMeal = props.location.state.idMeal;
    const [detaille, setDetaille] = useState([]);
    //Récupération des valeurs du tableau par nom de pays à l'aide du axios qui permet de récupérer des données HTTP à l'API rest (lancer une 'get')
    useEffect(() => {
        axios.get(`https://www.themealdb.com/api/json/v1/1/lookup.php?i=${idMeal}`).then((res) => {
        setDetaille(res.data[0]);

    });
     }, [idMeal]); // res.data = tout le tableau des pays...  res.data.[0] est la valeur dans la boîte [1] du tabeau des pays

    //Frontend = return (what you will see)
    return( //Mon code HTML - seulement un item à la fois, donc mettre tout dans 1 DIV (plusieurs items dans 1 item)
    <div className="details">
        <h1>{detaille.strMeal}</h1>
        <h4>{detaille.strCategory}</h4>
        <h4>{detaille.strYoutube}</h4>
    </div>
    )

}

//Export de la composante
export default Detaille;

