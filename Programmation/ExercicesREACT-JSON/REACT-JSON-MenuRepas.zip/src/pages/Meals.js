//Importations
import React from "react";
import Navigation from "../components/Navigation";
import Logo from "../components/Logo";
import Menu from "../components/Menu";

//Création du composant
const Meals = () => {
    //Backend
    //Frontend
    return(
        <div className="meals">
            <Logo />
            <Navigation />
            <br></br>
            <Menu />
        </div>
    )
}

//Exportation du composant
export default Meals;