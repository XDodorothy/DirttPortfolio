//Importations
import React from "react";
import Meals from "./pages/Meals";
import Categories from "./pages/Categories";
import Detaille from "./pages/Detaille";
import { BrowserRouter, Switch, Route } from "react-router-dom";


//Création du composant
const App = () => {
    //Frontend
    return(
      <BrowserRouter>
      <Switch>
       <Route path="/" exact component={Meals}/>
       <Route path="/categories" exact component={Categories}/>
       <Route path="/Details" exact component={Detaille} /> {/*Troisième page Mais qui ne sera pas dans le Menu de navigation, car c'est une page d'history qui montre les détails d'un pays une fois cliqué dessus. On le mets dans App.js pour créer sa route*/}

      </Switch>
     </BrowserRouter>
    )
}

//Exportation du composant
export default App;