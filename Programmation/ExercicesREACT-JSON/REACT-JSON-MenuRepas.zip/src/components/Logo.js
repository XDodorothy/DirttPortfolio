import React from "react";

const Logo = () => {
    return (
        <div className="logo">
            <img src="the_meal_db_api.png" alt="logo du site" />
         
        </div>
    )
}

export default Logo;
