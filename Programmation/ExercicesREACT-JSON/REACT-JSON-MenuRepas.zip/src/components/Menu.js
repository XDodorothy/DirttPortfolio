import React, { useState, useEffect } from "react";
import axios from "axios";
import Details from "./Details";
import { useHistory } from "react-router-dom"; // Besoin pour la page CountryDetails.js (History)


const Menu = () => {


    //variable devient état (state)
    const [plates, setPlates] = useState([]);
    const history = useHistory(); // C,est une fonction, donc () après le no de la fonction


    useEffect(() => {
        axios.get("https://www.themealdb.com/api/json/v1/1/search.php?f=b").then((res) => setPlates(res.data.meals));
    }, []); //tableau d'injection

    
    return(
        <div>
            <ul className="menu">
                {plates.map((p) => (
                    <Details plates={p} 
                    onClickDetaille = {() => history.push("/Details", {idMeal : p.idMeal})}/>
                ))}
            </ul>    
        </div> 
    )
}


export default Menu;