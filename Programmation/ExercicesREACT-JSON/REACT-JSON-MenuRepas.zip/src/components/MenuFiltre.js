import React, { useState, useEffect } from "react";
import axios from "axios";
import Details from "./Details";
import { useHistory } from "react-router-dom"; // Besoin pour la page CountryDetails.js (History)


const Menu = () => {


    //variable devient état (state)
    const [plates, setPlates] = useState([]);
    const radios = ["Dessert", "Beef", "Vegetarian", "Side", "Breakfast"];
    const [selectedRadio, setSelectedRadio] = useState("");
    const history = useHistory(); // C,est une fonction, donc () après le no de la fonction


    useEffect(() => {
        axios.get("https://www.themealdb.com/api/json/v1/1/search.php?f=b").then((res) => setPlates(res.data.meals));
    }, []); //tableau d'injection

   
    return(
        <div>
                <div className="sort-container">
                    <ul>
                        {radios.map((r) => {
                            return (
                                <li>
                                    <input 
                                      type="radio"
                                      name="radios"
                                      value={r}
                                      onChange={(e) => setSelectedRadio(e.target.value)}
                                      checked={selectedRadio == r}
                                    />
                                    <label>{r}</label>
                                </li>
                            )
                        })}
                    </ul>
                </div>
                <div className="cancel">
                    {/* {selectedRadio ? (<button onClick={() => setSelectedRadio("")}>Annuler le filtre</button>) : (<p></p>)} */}
                    {selectedRadio && (<button onClick={() => setSelectedRadio("")}>Reset filter</button>)}              
                </div>
                <ul className="menu">
                {selectedRadio && plates
                .filter((p) => p.strCategory.includes(selectedRadio))
                .map((p) => (
                    <Details plates={p}
                    onClickDetaille = {() => history.push("/Details", {idMeal : p.idMeal})} />
                ))}
                </ul>
        </div> 
    )
}


export default Menu;