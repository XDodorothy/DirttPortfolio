import React from "react";


const Details = (props) => {

    const { plates, onClickDetaille } = props;
    
    return(
        <div className="details">
            <img src={plates.strMealThumb} alt="meals" onClick={onClickDetaille} />
            <div className="conteneur">
                <li>{plates.strMeal}</li>
                <li>{plates.strArea}</li>
            
            </div>
        </div> 
    )
}


export default Details;