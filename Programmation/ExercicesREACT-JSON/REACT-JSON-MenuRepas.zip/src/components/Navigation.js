//Importations
import React from "react";
import { NavLink } from "react-router-dom";

//Création du composant
const Navigation = () => {
    //Backend
    //Frontend
    return(
        <div className="navigation">
            <NavLink exact to="/" activeClassName="nav-active">
                Meals
            </NavLink>
            <NavLink exact to="/categories" activeClassName="nav-active">
                Categories
            </NavLink>
        </div>
    )
}

//Exportation du composant
export default Navigation;