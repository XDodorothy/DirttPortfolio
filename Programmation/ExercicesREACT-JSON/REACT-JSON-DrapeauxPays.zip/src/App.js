//VRAI FICHIER QUI MONTRE LE SITE WEB SUR LE NAVIGATEUR
//Connecter la page que nous voulons voir quand on ouvre le site web Carte
//Copie-Colle le stuff de la page désirée (ici - Home). Remplacer tous les Home par App. Ensuite on retravaille le contenu pour l'adpter au App que nous voulons.


//Imports
import React from "react";
//Puis, on rajoute l'import route: import { BrowserRouter, Switch, Route } from "react-router-dom";
import { BrowserRouter, Switch, Route } from "react-router-dom";
//Et coller les Pages Home et About - exporter (du pourquoi la ligne Export dans les fichiers)
import Home from "./pages/Home";  
import About from "./pages/About";
import CountryDetails from "./pages/CountryDetails";
import NotFound from "./pages/NotFound";
import News from "./pages/News";

//Fonction normale --> MÊME CHOSE QUE FLECHÉES, mais nous allons toujours utilisée Fechées, car plus populaire/standard
/*function App() {}*/
//Création composante (Créer une fonction fléchée)
const App = () => {
  //Backend
  //Frontend = return (what you will see)
  return( //Mon code HTML - seulement un item à la fois, donc mettre tout dans 1 DIV (plusieurs items dans 1 item)

  <BrowserRouter>
    <Switch>
      <Route path="/" exact component={Home}/> {/*Première page - Page accueil (Home) toujours "/" + titre de page - ex: www.google.ca/ */}
      <Route path="/news" exact component={News}/> 
      <Route path="/a-propos" exact component={About} /> {/*Deuxième page - www.google.ca/a-propos qui vient de la page About.js */}
      <Route path="/countryDetails" exact component={CountryDetails} /> {/*Troisième page Mais qui ne sera pas dans le Menu de navigation, car c'est une page d'history qui montre les détails d'un pays une fois cliqué dessus. On le mets dans App.js pour créer sa route*/}
      <Route exact component={NotFound} /> {/* pas de PATH car cette page apparaît quand la page recherchée n'existe pas */}
    </Switch>
  </BrowserRouter>
 
  )
  
}

//Export de la composante
export default App;