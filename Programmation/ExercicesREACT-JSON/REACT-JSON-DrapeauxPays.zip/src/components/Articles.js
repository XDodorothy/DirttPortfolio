//Imports
import React from "react";
import axios from "axios"; // utilisé pour la fonction 'handleDelete'

//Fonction normale --> MÊME CHOSE QUE FLECHÉES, mais nous allons toujours utilisée Fechées, car plus populaire/standard
/*function Articles() {}*/
//Création composante (Créer une fonction fléchée)
const Article = (props) => {
    //Backend
    const { article } = props; // APPEL onClickCountry qui est dans le Countries.js créé pour rediriger la personne vers CountryDetail.js quand clique sur le drapeau
    //Frontend = return (what you will see)
    const dateConverter = (date) => {
        //On crée une date
        
        let newDate = new Date(date).toLocaleString('fr-FR',{ // Fonction pour convertir time unix à locale JS
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: 'numeric',
            second: 'numeric'});
            return newDate; // renvoie le bon format de date
        }
        //Fonction de Suppression liée avec le bouton 'Supprimer'
        const handleDelete = () => {
            if(window.confirm("Voulez-vous vraiment supprimer cet article ?")) // renvoie 'true'
            {
                axios.delete("http://localhost:3005/articles/" + article.id) // en JS, pas besoin des ${id}, mettre '+ ...'
                .then(() => {
                    window.location.reload(); // reload la page pur voir le changement / suppresison sur l'écran
                });
            }
        }
        // Fontion pour convertir time unix en locale francaises JS
        return( //Mon code HTML - seulement un item à la fois, donc mettre tout dans 1 DIV (plusieurs items dans 1 item)
        <div className="articles" > 
        <div className="card_header">
        <h3>{article.author}</h3>
        <em>Posté le {dateConverter(article.date)}</em>
        {/* Où 'date' est le nom du champ dans la base de données */}
        </div>
        
        <p>{article.content}</p>
        {/*Boutons modifier/supprimer*/}
        <div className="btn-container">
            <button>Modifier</button>
            <button onClick={handleDelete}>Supprimer</button>
        </div>
        
        
        </div>
    )
    
}

//Export de la composante
export default Article;