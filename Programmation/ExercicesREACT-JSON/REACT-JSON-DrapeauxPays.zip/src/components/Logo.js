//Imports
import React from "react";

//Fonction normale --> MÊME CHOSE QUE FLECHÉES, mais nous allons toujours utilisée Fechées, car plus populaire/standard
/*function Logo() {}*/
//Création composante (Créer une fonction fléchée)
const Logo = () => {
    //Backend
    //Frontend = return (what you will see)
    return( //Mon code HTML - seulement un item à la fois, donc mettre tout dans 1 DIV (plusieurs items dans 1 item)
    <div className="logo">
        <img src="logo192.png" alt="logo"/>
        <h3>Carte du monde</h3>
    </div>
    )

}

//Export de la composante
export default Logo;