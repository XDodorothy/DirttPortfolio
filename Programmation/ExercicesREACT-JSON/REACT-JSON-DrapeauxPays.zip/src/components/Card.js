//Imports
import React from "react";

//Fonction normale --> MÊME CHOSE QUE FLECHÉES, mais nous allons toujours utilisée Fechées, car plus populaire/standard
/*function Card() {}*/
//Création composante (Créer une fonction fléchée)
const Card = (props) => {
    //Backend
    const { pays, onClickCountry } = props; // APPEL onClickCountry qui est dans le Countries.js créé pour rediriger la personne vers CountryDetail.js quand clique sur le drapeau
    //Frontend = return (what you will see)
    return( //Mon code HTML - seulement un item à la fois, donc mettre tout dans 1 DIV (plusieurs items dans 1 item)
    <div className="card" onClick={onClickCountry}> 

      <img src={pays.flag} alt="Drapeau"/> {/*Afficher le drapeau c'est la portion "flag" de la base de données*/}
      <div className="conteneur"> {/*Afficher les infos du HOVER de la base de données - seront en absolute en css et l'image en relative*/}
        <li> {pays.name}</li>
        <li> {pays.capital}</li>
        <li> {pays.population}</li>
      </div>
    </div>
    )

}

//Export de la composante
export default Card;