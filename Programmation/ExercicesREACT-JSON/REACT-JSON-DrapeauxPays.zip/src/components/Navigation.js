//CECI EST POUR CRÉER UN MENU DE NAVIGATION
//Imports
import React from "react";
import { NavLink } from "react-router-dom";


//Fonction normale --> MÊME CHOSE QUE FLECHÉES, mais nous allons toujours utilisée Fechées, car plus populaire/standard
/*function Navigation() {}*/
//Création composante (Créer une fonction fléchée)
const Navigation = () => {
    //Backend
    //Frontend = return (what you will see)
    return( //Mon code HTML - seulement un item à la fois, donc mettre tout dans 1 DIV (plusieurs items dans 1 item)
    <div className='navigation'>
        <NavLink activeClassName="nav-active" exact to='/'> {/*Affiche la page dont le 'PATH' est '/'*/}
            Accueil {/*Titre apparaissant sur le menu*/}
        </NavLink>
        <NavLink activeClassName="nav-active" exact to='/news'> {/*Affiche la page dont le 'PATH' est '/a-propos'*/}
            News {/*Titre apparaissant sur le menu*/}
        </NavLink>
        <NavLink activeClassName="nav-active" exact to='/a-propos'> {/*Affiche la page dont le 'PATH' est '/a-propos'*/}
            À propos {/*Titre apparaissant sur le menu*/}
        </NavLink>
    </div>
    )

}

//Export de la composante
export default Navigation;
