//Imports
import React, { useEffect, useState } from "react";
import axios from "axios"; /*Importation de axios car nous avons besoin de récuperer des données de http à l'API Rest (lancer une get)*/
import Card from "./Card";
import { useHistory } from "react-router-dom"; // Besoin pour la page CountryDetails.js (History)

//Fonction normale --> MÊME CHOSE QUE FLECHÉES, mais nous allons toujours utilisée Fechées, car plus populaire/standard
/*function Logo() {}*/
//Création composante (Créer une fonction fléchée)
const Countries = () => {
    //Backend
    // DÉMO en Javascript
    /*let pays = [];
    pays = [2, 4, 7];
    let prenomo = "";
    prenom = "Mohamed";*/
    // MAINTENANT, var == un état (state)
    
    //const [nomvariable, nomfunction] = initialiser la variable -> useState(type de la variable (ex: tableau)) qui est à la ligne 2 ajoutée à react
    const [pays, setPays] = useState([]);
    //mettre à jour la variable pays (renvoyer les données (data))
    const radios = ["Africa", "Americas", "Asia", "Europe", "Oceania"];// Créer un tableau pour les boutons radio
    const [selectedRadio, setSelectedRadio] = useState(""); // Création d'un état (State) qui fera en sorte que le bouton radio selectionné montre les bons pays
    const history = useHistory(); // C,est une fonction, donc () après le no de la fonction
    
    useEffect(() => { // Pour ne faire exécuter un code juste une fois -- pour ne pas booster le système
        axios.get("https://restcountries.com/v2/all").then((res) => setPays(res.data));
    }, []); // le dernier [] est un tableau dinjection
    // afin d'exécuter l'action une fois que la première action ce termine/s'éxécute (ex, si le site restcountries est down) - Popur éviter les problèmes asyncrones
    //Si le server ne fonctionen pas : il returnera Code 500; si tout va bien Code 200
    //Programmation asyncrone; les lignes sont lues une à la suite de l'autre
    /*let taux = 0;
    taux = taux +1;
    print(taux);*/
    console.log(pays); //afficher la variable pays pour checker si ce sont les données que nous voulons (nous avons fait la bonne connection/selection)
    
    //Frontend = return (what you will see)
    return( //Mon code HTML - seulement un item à la fois, donc mettre tout dans 1 DIV (plusieurs items dans 1 item)
    <div >
    
    {/*ENSUITE, nous voulons afficher le noms des 250 pays
    OBJECTIF: Afficher chaque nom de pays dans une liste <li>
    Nous allons mapper, chaque p (pays) et afficher le "name" dans la base de données (p = toutes les tables dans un pays)
les { dans les ul est pour intégrer du Javascript dans le return*/}

<div className="sort-container">
<ul>
{radios.map((r) => { // Comme nous avons un li avec des enfants html, nous devons l'incorporer dans un second 'return'
    return (
        <li>
        <input  type="radio" name="radios" value={r} onChange={(e) => setSelectedRadio(e.target.value)} checked={selectedRadio == r}/> {/*'name' fait en sorte que un seul bouton peut être selectionné. "value" est la valeur récupérée pour comparer dans le tableau des Pays'. onClick c'est pour les bouton non-radios. le "e" vient d'une formule prédéfini (TOUJOURS mettre 'e')Le bouton est 'Checked' seulement quand selectedRadio est plein -- donc quand c'est réinitialisé avec la structure ternaire, le bouton s'éteint ... SINON, tout fonctionne, mais le bouton reste allumé*/}
            <label>{r}</label>  
        </li>
        )
    })}
    </ul>
    </div>
    <div className="cancel"> {/*Bouton de réinitialisation SEULEMENT visible quand 1 bouton est selectionné --> Lorsque la variable selectedRegion est pleine (contient quelque chose) == bouton selectionné 
    (selectedRadio != "") ? jaffiche le bouton : jaffiche un p vide - structure ternaire
            FAIRE CECI SI on veut écrire quelque chose dans le "else":
            {selectedRadio ? (<button onClick={() => setSelectedRadio("") }> Annuler le filtre </button>) : (<p></p>)} 
            ET FAIRE SI DESSOUS SI on veut juste faire disparaître
            true && button --> button == élément html
            false && button = rien du tout*/}
        {selectedRadio && (<button onClick={() => setSelectedRadio("") }> Annuler le filtre </button>) }  {/*setSelectedRadio est remise à aucune valeur dans son tableau et donc tous les Pays s'affichent et comme setSelectedRadio est vide --> le bouton disparaît*/}
    </div>
    <ul className="countries">
    {pays
    .filter((p) => p.region.includes(selectedRadio)) /*Filtrer avant de mapper avec le Pays selectionnée par l'utilisateur avec le bouton radio*/
    .map((p) => ( 
        <Card 
        pays={p} 
        key={p.name}
        onClickCountry = {() => history.push("/countryDetails", {name : p.name})}/>  /*Appelle composent Card pour faire la loop pour afficher les drapeaux et info des pays - On va envoyer une donnée par Props (la props que nous voulons envoyer s'appelle pays que nous avons nommée 'p' plus haut
        Besoin de faire un display flex pour les aligner en tableau (countries.scss), terme KEY est pour donner une clé primaire à chaque pays. donc trouver une info du tableau qui est unique à chaque pays - ici: "name" (aucun pays n'ont pas le même 'name'
        OnClickCountry: crée par nous pour implementer le clique quand on clique sur un drapeau, QUOI FAIRE -> Aller à la page CountryDetails.js (qui est '/countrydetails' dans la route App.js*/
        ))}
        </ul>
        
        </div>
        )
        
    }
    
    //Export de la composante
    export default Countries;