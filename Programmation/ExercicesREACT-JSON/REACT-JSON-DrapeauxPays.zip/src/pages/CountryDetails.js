//Imports
import React, {useState, useEffect} from "react";
import axios from "axios";

//Fonction normale --> MÊME CHOSE QUE FLECHÉES, mais nous allons toujours utilisée Fechées, car plus populaire/standard
/*function Home() {}*/
//Création composante (Créer une fonction fléchée)
const CountryDetails = (props) => { // toujours mettre PROPS dans les parenthèses quand on l'utilise
    //Backend

    const name = props.location.state.name;
    const [detail, setDetail] = useState([]);
    //Récupération des valeurs du tableau par nom de pays à l'aide du axios qui permet de récupérer des données HTTP à l'API rest (lancer une 'get')
    const [currencies, setCurrencies] = useState([]); // Récupéré la donnée Currencies (qui est un tableau dans le tableau principal). On lui crée un état (State) pour récupérer ses données à l'intérieur
    useEffect(() => {
        axios.get(`https://restcountries.com/v2/name/${name}`).then((res) => {
        setDetail(res.data[0]);
        setCurrencies(res.data[0].currencies);
    });
     }, [name]); // res.data = tout le tableau des pays...  res.data.[0] est la valeur dans la boîte [1] du tabeau des pays

    //Frontend = return (what you will see)
    return( //Mon code HTML - seulement un item à la fois, donc mettre tout dans 1 DIV (plusieurs items dans 1 item)
    <div className="country-details">
        <img src={detail.flag}/>
        <h1>{detail.name}</h1>
        <h4>{detail.population}</h4>
        <h4>{detail.region}</h4>

        <div className="currencies">
            <h4>Currencies :</h4>
            {currencies.map((c) => { //'c' c'est toutes les données incluses dans le tableau 'currencies'
                return(
                    <h4>{c.name}</h4>
                )
            })}
        </div>

    </div>
    )

}

//Export de la composante
export default CountryDetails;

