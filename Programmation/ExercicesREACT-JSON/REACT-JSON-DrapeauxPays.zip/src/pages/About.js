//Imports
import React from "react";
import Logo from "../components/Logo";
import Navigation from "../components/Navigation";

//Fonction normale --> MÊME CHOSE QUE FLECHÉES, mais nous allons toujours utilisée Fechées, car plus populaire/standard
/*function About() {}*/
//Création composante (Créer une fonction fléchée)
const About = () => {
    //Backend
    //Frontend = return (what you will see)
    return( //Mon code HTML - seulement un item à la fois, donc mettre tout dans 1 DIV (plusieurs items dans 1 item)
    <div>
        <Logo />
        <Navigation /> {/*Emplacement du Menu de Nav*/} 
        <h1>About</h1>
        <p>Je suis un extraterrestre</p>
    </div>
    )

}

//Export de la composante
export default About;