//Imports
import React from "react";
import Logo from "../components/Logo";
import Navigation from "../components/Navigation";
import Countries from "../components/Countries";

//Fonction normale --> MÊME CHOSE QUE FLECHÉES, mais nous allons toujours utilisée Fechées, car plus populaire/standard
/*function Home() {}*/
//Création composante (Créer une fonction fléchée)
const Home = () => {
    //Backend
    //Frontend = return (what you will see)
    return( //Mon code HTML - seulement un item à la fois, donc mettre tout dans 1 DIV (plusieurs items dans 1 item)
    <div>
        <Logo /> {/*Importation du component Logo*/}
        <Navigation /> {/*Emplacement du Menu de Nav*/} 
        <Countries />

    </div>
    )

}

//Export de la composante
export default Home;

