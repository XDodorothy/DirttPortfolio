//Imports
import React, { useEffect, useState } from "react";
import axios from "axios";
import Logo from "../components/Logo";
import Navigation from "../components/Navigation";
import Article from "../components/Articles";



//Fonction normale --> MÊME CHOSE QUE FLECHÉES, mais nous allons toujours utilisée Fechées, car plus populaire/standard
/*function News() {}*/
//Création composante (Créer une fonction fléchée)
const News = () => {

    const [newsData, setNewsData] = useState ([]);
    const [author, setAuthor] = useState("");
    const [content, setContent] = useState("");
    //Représenter l'erreur (pas assez de caractères) avec un script
    const [error, setError] = useState(false); // défaut: pas d'erreur
    //Fonction qui va lancer AXIOS.GET
    const getData = () => {
        axios.get("http://localhost:3005/articles").then((res) => setNewsData(res.data));
    }

    useEffect(() => {
        getData(); // Montrer les données ajoutées
    }, []);

    const handleSubmit = (e) => {

        e.preventDefault();    //préviens l'envoie du formulaire en cas de if/else (fonction conditionnelle). Si pas là, le formulaire ne pourra pas s'envoyer

        //Gestion erreur
        if (content.length < 140) {
            setError(true); // en frontend, on pourra l'utiliser et dire 'fait ceci, si setError = true'
        }
        else {//Lancer un POST
            axios.post("http://localhost:3005/articles", {
                author,content, 
                date: Date.now() // génère la date et heure du jour pour chaque nouvelle entrée
            }).then(() => {
                setAuthor("");
                setContent("");
                setError(false); // remettre l'erreur à 'false' pour que le texte message d'erreur et les couleurs quand il y a assez de caractères
                getData();
                //Ou alors, faire un code pour rlancer la page .. ce qui fera la même chose que ci-haut: Ci-bas, la version courte et simple à utiliser normalement
                //window.location.reload();
            })
        }
        
    }
    //Backend
    //Frontend = return (what you will see)
    return( //Mon code HTML - seulement un item à la fois, donc mettre tout dans 1 DIV (plusieurs items dans 1 item)
    <div className="news">
        <Logo />
        <Navigation />
        <h1> NEWS </h1>
        <form onSubmit= {(e) => handleSubmit(e)}>
            <input type="text"
            placeholder="Nom du pays"
            value={author}
            onChange={(e) => setAuthor(e.target.value)}></input>


            <textarea type="text"
            placeholder="Contenu de l'article"
            value={content}
            onChange={(e) => setContent(e.target.value)} style={{border: error ? "1px solid red" : "1px solid #61dafb"}}></textarea> {/* Style à la ligne pour vraiment cibler et effectuer des if ternaires et ainsi faciliter l'exécusion d'erreur
            Si on écrit : ( error ? border:"1px solid red" : border:"1px solid blue"), il y a interférance avec le ':' du ternaire, donc il faut mettre le 'border: en avant*/}
            {error && <p className="error">Veuillez entrer un minimum de 140 caractères</p>} {/*Si error = true, affiche le message d'erreur*/}
            <input type="submit" value="Ajouter"></input>
        </form>
        <ul>
            {newsData.map((a) => (
                <Article article={a} key={a.id} />
            ))}
        </ul>
    </div>
    )

}

//Export de la composante
export default News;

