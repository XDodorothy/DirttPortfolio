//Importations
import React from "react";
import { NavLink } from "react-router-dom";

//Création du composant
const Navigation = () => {
    //Backend
    //Frontend
    return(
        <div className="navigation">
            <NavLink exact to="/" activeClassName="nav-active">
                Add an employee
            </NavLink>
            <NavLink exact to="/show" activeClassName="nav-active">
                Show employees
            </NavLink>
        </div>
    )
}

//Exportation du composant
export default Navigation;