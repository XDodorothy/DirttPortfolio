import React from "react";

const Logo = () => {
    return (
        <div className="logo">
            <img src="nerd.png" alt="logo du site" />
        
        </div>
    )
}

export default Logo;
