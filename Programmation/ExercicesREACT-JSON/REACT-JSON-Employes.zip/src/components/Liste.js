import React from "react";

const Liste = (props) => {

    const { liste } = props;
    return (
        <div className="liste-card">
            <p>Name: {liste.name}</p>
            <p>Salary: {liste.salary}$</p>
            <p>Age: {liste.age}</p>
        </div>
    )
}

export default Liste;