import React, { useState, useEffect } from "react";
import axios from "axios";
import Logo from "../components/Logo";
import Navigation from "../components/Navigation";
import Liste from "../components/Liste";

const Affichage = () => {

    const [data, setData] = useState([]);
    const [orderChoice, setOrderChoice] = useState("");

    useEffect(() => {
        axios.get("http://localhost:3006/liste").then((res) => setData(res.data));
    }, []);

    return (
        <div className="affichage">
            <Logo />
            <Navigation />
            <h3>Sorting Salaries</h3>
            <div className="sort-container" onChange={(e) => setOrderChoice(e.target.value)}>
                <input type="radio" name="ordre" value="asc" />Low to high
                <input type="radio" name="ordre" value="desc" />High too low
            </div>
            <ul className="list-employees">
            {(orderChoice) ? (
                ((orderChoice == "asc") ? (
                    data
                       .sort((x, y) => x.salary - y.salary)
                       .map((e) => (
                        <Liste liste={e} key={e.id} />
                       ))
                ) : (
                    data
                       .sort((x, y) => y.salary - x.salary)
                       .map((e) => (
                        <Liste liste={e} key={e.id} />
                ))
            ))
            ) : (
                data.map((e) => (
                    <Liste liste={e} key={e.id} />

                ))
            )}
            </ul>
        </div>
    )
}

export default Affichage;