import React, { useState } from "react";
import axios from "axios";
import Logo from "../components/Logo";
import Navigation from "../components/Navigation";

const Saisie = () => {

    const [name, setName] = useState("");
    const [salary, setSalary] = useState();
    const [age, setAge] = useState("");

    const addNewEmployee = () => {
        axios.post("http://localhost:3006/liste", {
            name: name, 
            salary: parseFloat(salary), 
            age: parseFloat(age),
        }).then(() => {
            setName("");
            setSalary();
            setAge("")
        });
        window.alert("Employee added");
    }

    return (
        <div className="saisie">
            <Logo />
            <Navigation />
            <h3>Add an employee</h3>
            <form onSubmit={() => addNewEmployee()}>
                <input 
                  type="text"
                  placeholder="Full Name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
                <input 
                  type="number"
                  placeholder="Annual Salary"
                  value={salary}
                  onChange={(e) => setSalary(e.target.value)}
                />
                <input 
                  type="number"
                  placeholder="Age"
                  value={age}
                  onChange={(e) => setAge(e.target.value)}
                />
                <input type="submit" value="Add" />
            </form>
        </div>
    )
}

export default Saisie;