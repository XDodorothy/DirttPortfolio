//Importations
import React from "react";
import { BrowserRouter, Switch, Route } from "react-router-dom";
import Saisie from "./pages/Saisie";
import Affichage from "./pages/Affichage";
import NotFound from "./pages/NotFound";


//Création du composant
const App = () => {
  //Frontend
  return(
    <BrowserRouter>
    <Switch>
    <Route path="/" exact component={Saisie} />
    <Route path="/show" exact component={Affichage} />
    <Route exact component={NotFound} />
    </Switch>
    </BrowserRouter>
  )
}

//Exportation du composant
export default App;